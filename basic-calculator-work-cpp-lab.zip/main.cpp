/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

int main()
{
    int add,subtract,multiply,divid,first,second;
    float divide;
    cout<<"please entre a two number :";
    cin>>first>>second;
    
    add=first+second;
    subtract=first-second;
    multiply=first*second;
    divid=first/float(second);
    
    cout<<"sum of two number ="<<add<<endl;
    cout<<"subtraction of a two number="<<subtract<<endl;
    cout<<"multiplication of a two number="<<multiply<<endl;
    cout<<"division of a two number ="<<divid<<endl;

    return 0;
}