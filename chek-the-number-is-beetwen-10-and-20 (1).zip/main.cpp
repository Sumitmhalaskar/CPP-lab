/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
 using namespace std;
int main()
{
   int number;
   cout<<"entre a number :";
   cin>>number;
   
   if(number>=10&&number<=20){
       cout<<"the number is beetween 10 and 20:"<<endl;
   }
   else{
       cout<<"the number is not a beetween a 10 and 20:";
   }

    return 0;
}