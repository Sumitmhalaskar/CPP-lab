/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main() {
int num;

// Prompt user for input
cout << "Enter a number: ";
cin >> num;
// Check if the number is between 10 and 20 (inclusive)
if (num >= 10 && num <= 20) {
cout << "The number " << num << " is between 10 and 20 " <<endl;

} else {
cout << "The number " << num << " is not between 10 and 20 "<<endl;
}
return 0;
}